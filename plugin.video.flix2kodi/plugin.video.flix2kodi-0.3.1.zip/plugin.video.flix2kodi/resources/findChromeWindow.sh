#!/bin/bash
/usr/bin/xdotool search "Google Chrome"
