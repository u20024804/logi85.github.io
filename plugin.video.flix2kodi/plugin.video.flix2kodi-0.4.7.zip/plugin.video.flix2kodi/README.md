# plugin.video.flix2kodi
kodi addon

please DONT install this addon from here.
please read instructions @ http://forum.kodi.tv/showthread.php?tid=254263

Big thanks to z-e-r-o and many others making this addon possible.